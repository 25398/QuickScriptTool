/* 鼠大侠网页键鼠桥 — MV3 service worker（WebSocket 直接连本机桥） */
const BRIDGE_VERSION = "1.0.8";
const PORT_LO = 19228;
const PORT_HI = 19240;
const RECONNECT_MS = 1500;

let ws = null;
/** @type {{tabId?: number, targetId?: string}|null} */
let attachedDebuggee = null;
let attachMeta = { dpr: 1, offsetX: 0, offsetY: 0, focus: "", url: "" };
let lastStatus = { state: "idle", detail: "" };
let discoverBusy = false;
let cdpLogLeft = 8;

function setStatus(state, detail) {
  lastStatus = { state, detail: detail || "" };
  chrome.storage.local.set({ bridgeStatus: lastStatus });
}

function stripBrowserSuffix(s) {
  let t = (s || "").trim();
  for (;;) {
    const m = t.match(/^(.*)(\s[-–—]\s)(.+)$/);
    if (!m) break;
    const tail = m[3];
    if (
      /Microsoft\s*Edge/i.test(tail) ||
      /Google\s*Chrome/i.test(tail) ||
      /用户配置/.test(tail) ||
      /^Profile\s*\d+/i.test(tail) ||
      /InPrivate/i.test(tail)
    ) {
      t = m[1].trim();
      continue;
    }
    break;
  }
  return t;
}

function titleMatch(hint, title) {
  if (!hint || !title) return false;
  const h = stripBrowserSuffix(hint);
  const t = stripBrowserSuffix(title);
  if (!h || !t) return false;
  if (t.includes(h) || h.includes(t)) return true;
  const core = (s) => s.split(/[-–—|]/)[0].trim();
  const hc = core(h);
  const tc = core(t);
  return !!(hc && tc && (tc.includes(hc) || hc.includes(tc)));
}

function isUtilityTarget(t) {
  const u = t.url || "";
  const title = t.title || "";
  if (u.startsWith("edge://") || u.startsWith("chrome://") || u.startsWith("devtools://")) return true;
  if (u.startsWith("chrome-extension://") || u.startsWith("extension://")) return true;
  if (title.includes("edge://inspect") || title.includes("chrome://inspect")) return true;
  if (u === "" && title === "") return true;
  if (title === "about:blank") return true;
  return false;
}

function gameUrlScore(url) {
  const u = (url || "").toLowerCase();
  let s = 0;
  if (!u || u === "about:blank") return -1;
  if (u.includes("h.api.4399") || u.includes("g.php?gameid") || u.includes("g.php?gameId")) s += 40;
  if (u.includes("4399")) s += 20;
  if (u.includes("7k7k")) s += 12;
  if (u.includes("minigame") || u.includes("h5game")) s += 10;
  if (u.includes("game") || u.includes("play")) s += 6;
  if (u.includes("swf") || u.includes("unity") || u.includes("wasm")) s += 5;
  if (u.includes("login") || u.includes("passport") || u.includes("account")) s -= 8;
  return s;
}

async function collectGameTargets(pageDebuggee, pageTabId, knownGameUrl) {
  const notes = [];
  try {
    await chrome.debugger.sendCommand(pageDebuggee, "Target.setDiscoverTargets", {
      discover: true,
    });
  } catch (e) {
    notes.push("discover:" + (e && e.message ? e.message : e));
  }
  try {
    await chrome.debugger.sendCommand(pageDebuggee, "Target.setAutoAttach", {
      autoAttach: true,
      waitForDebuggerOnStart: false,
      flatten: true,
    });
  } catch (e) {
    notes.push("autoAttach:" + (e && e.message ? e.message : e));
  }

  // 等 OOPIF 出现在 target 列表里
  await new Promise((r) => setTimeout(r, 600));

  const byId = new Map();
  const add = (raw) => {
    const id = raw.id || raw.targetId;
    if (!id) return;
    const url = raw.url || "";
    const type = raw.type || "";
    const tabId = raw.tabId;
    const cur = byId.get(id) || { id, url: "", type: "", tabId: undefined };
    if (url) cur.url = url;
    if (type) cur.type = type;
    if (typeof tabId === "number") cur.tabId = tabId;
    byId.set(id, cur);
  };

  for (const t of await listTargets()) add(t);
  try {
    const r = await chrome.debugger.sendCommand(pageDebuggee, "Target.getTargets");
    for (const t of (r && r.targetInfos) || []) add(t);
  } catch (e) {
    notes.push("cdpGetTargets:" + (e && e.message ? e.message : e));
  }

  // 再扫一轮（autoAttach 后有时会晚一点）
  await new Promise((r) => setTimeout(r, 400));
  for (const t of await listTargets()) add(t);
  try {
    const r = await chrome.debugger.sendCommand(pageDebuggee, "Target.getTargets");
    for (const t of (r && r.targetInfos) || []) add(t);
  } catch (_) {
    /* ignore */
  }

  const known = (knownGameUrl || "").toLowerCase();
  const all = [...byId.values()].map((t) => {
    let score = gameUrlScore(t.url);
    if (t.type === "iframe") score += 8;
    if (t.type === "page" && /g\.php|h\.api\.4399/i.test(t.url || "")) score += 12;
    if (typeof t.tabId === "number" && t.tabId === pageTabId) score += 4;
    if (typeof t.tabId === "number" && t.tabId !== pageTabId) score -= 100;
    if (known && t.url) {
      if (t.url === knownGameUrl) score += 50;
      if (known.includes("gameid=") && t.url.toLowerCase().includes("gameid=")) score += 25;
      if (t.url.includes("h.api.4399.com")) score += 20;
    }
    // 排除当前壳页自身（通常不是 g.php）
    if (t.type === "page" && typeof t.tabId === "number" && t.tabId === pageTabId) {
      if (!/g\.php|h\.api\.4399/i.test(t.url || "")) score -= 30;
    }
    return { ...t, score };
  });
  const list = all.filter((t) => t.score >= 10).sort((a, b) => b.score - a.score);

  // 诊断：列出带 4399/game 的全部 target（即使未入选）
  const hint = all
    .filter((t) => /4399|g\.php|game/i.test(t.url || "") || t.type === "iframe")
    .slice(0, 8)
    .map((t) => `${t.type}:${t.score}:${(t.url || "").slice(0, 70)}`);
  notes.push("candidates=" + list.length);
  notes.push("all=" + byId.size);
  if (hint.length) notes.push("hint=" + hint.join(" || "));
  else notes.push("hint=none");
  return { list, notes };
}

async function tryAttachTarget(targetId) {
  const dbg = { targetId };
  try {
    await chrome.debugger.attach(dbg, "1.3");
    return { ok: true, debuggee: dbg, err: "" };
  } catch (e) {
    const msg = String(e && e.message ? e.message : e);
    if (/already\s*attached/i.test(msg)) {
      return { ok: true, debuggee: dbg, err: "already" };
    }
    return { ok: false, debuggee: null, err: msg };
  }
}

async function listTargets() {
  try {
    return await chrome.debugger.getTargets();
  } catch (_) {
    return [];
  }
}

async function pickPage(titleHint) {
  const hint = (titleHint || "").trim();
  const pages = (await listTargets()).filter(
    (t) => t.type === "page" && typeof t.tabId === "number" && !isUtilityTarget(t)
  );
  const candidates = pages.map((p) => p.title || p.url || "(无标题)");
  if (hint) {
    for (const p of pages) {
      if (titleMatch(hint, p.title || "")) return { page: p, candidates };
    }
    return { page: null, candidates };
  }
  if (pages.length === 1) return { page: pages[0], candidates };
  return { page: null, candidates };
}

async function detachDebugger() {
  if (!attachedDebuggee) return;
  try {
    await chrome.debugger.detach(attachedDebuggee);
  } catch (_) {
    /* ignore */
  }
  attachedDebuggee = null;
  attachMeta = { dpr: 1, offsetX: 0, offsetY: 0, focus: "", url: "" };
}

async function prepareFocusAndMetrics(pageDebuggee) {
  const meta = { dpr: 1, offsetX: 0, offsetY: 0, focus: "page", url: "" };
  try {
    await chrome.debugger.sendCommand(pageDebuggee, "Emulation.setFocusEmulationEnabled", {
      enabled: true,
    });
  } catch (_) {
    /* optional */
  }
  // 不要 Page.bringToFront：会把已最小化的 Edge 从「鼠标宏」桌面唤醒，
  // 导致用户桌面任务栏/多桌面预览仍能看到该窗口。
  try {
    const dprRes = await chrome.debugger.sendCommand(pageDebuggee, "Runtime.evaluate", {
      expression: "Number(window.devicePixelRatio)||1",
      returnByValue: true,
    });
    const dpr = Number(dprRes && dprRes.result && dprRes.result.value);
    if (dpr > 0.1 && dpr < 8) meta.dpr = dpr;
  } catch (_) {
    /* keep 1 */
  }
  try {
    const focusRes = await chrome.debugger.sendCommand(pageDebuggee, "Runtime.evaluate", {
      expression: `(() => {
        const score = (u) => {
          u = (u || "").toLowerCase();
          let s = 0;
          if (u.includes("4399")) s += 20;
          if (u.includes("game") || u.includes("play")) s += 6;
          if (u.includes("login") || u.includes("passport")) s -= 8;
          return s;
        };
        const frames = [...document.querySelectorAll("iframe")];
        frames.sort((a, b) => score(b.src) - score(a.src));
        const f = frames.find((x) => score(x.src) > 0) || frames[0];
        if (f) {
          try { f.scrollIntoView({ block: "center", inline: "center" }); } catch (e) {}
          try { f.focus(); } catch (e) {}
          try { f.contentWindow && f.contentWindow.focus(); } catch (e) {}
          const r = f.getBoundingClientRect();
          return {
            focus: "iframe",
            x: r.left,
            y: r.top,
            w: r.width,
            h: r.height,
            src: f.src || "",
          };
        }
        const c = document.querySelector("canvas");
        if (c) {
          try { c.tabIndex = c.tabIndex || 0; c.focus(); } catch (e) {}
          const r = c.getBoundingClientRect();
          return { focus: "canvas", x: r.left, y: r.top, w: r.width, h: r.height, src: "" };
        }
        try { window.focus(); } catch (e) {}
        return { focus: "window", x: 0, y: 0, w: innerWidth, h: innerHeight, src: location.href || "" };
      })()`,
      returnByValue: true,
    });
    const v = focusRes && focusRes.result && focusRes.result.value;
    if (v && typeof v === "object") {
      meta.focus = String(v.focus || "page");
      meta.url = String(v.src || "");
      // 仅当后续改 attach 到 iframe 视口时才需要 offset；默认仍按顶层页坐标投递
      meta.offsetX = 0;
      meta.offsetY = 0;
      meta.iframeCssX = Number(v.x) || 0;
      meta.iframeCssY = Number(v.y) || 0;
      meta.iframeCssW = Number(v.w) || 0;
      meta.iframeCssH = Number(v.h) || 0;
    }
  } catch (_) {
    /* ignore */
  }
  return meta;
}

async function attachTab(titleHint) {
  const { page, candidates } = await pickPage(titleHint);
  if (!page) {
    setStatus("no-tab", `未匹配到目标页（可见 ${candidates.length} 个）`);
    return {
      ok: false,
      error: "NO_TAB",
      message: "未找到匹配的游戏标签页",
      candidates: candidates.slice(0, 12),
      version: BRIDGE_VERSION,
    };
  }

  await detachDebugger();

  const pageDebuggee = { tabId: page.tabId };
  try {
    await chrome.debugger.attach(pageDebuggee, "1.3");
  } catch (e) {
    return {
      ok: false,
      error: "DEBUGGER_DENIED",
      message: String(e && e.message ? e.message : e),
      version: BRIDGE_VERSION,
    };
  }

  let meta = await prepareFocusAndMetrics(pageDebuggee);
  let debuggee = pageDebuggee;
  let attachedVia = "tab";
  let attachNote = "";

  // 先点一下游戏 iframe 中心，尽量激活（仍可能因跨域不够，后面会挂 iframe target）
  try {
    const ix = (Number(meta.iframeCssX) || 0) + Math.max(10, (Number(meta.iframeCssW) || 0) / 2);
    const iy = (Number(meta.iframeCssY) || 0) + Math.max(10, (Number(meta.iframeCssH) || 0) / 2);
    if (ix > 0 && iy > 0) {
      for (const type of ["mousePressed", "mouseReleased"]) {
        await chrome.debugger.sendCommand(pageDebuggee, "Input.dispatchMouseEvent", {
          type,
          x: ix,
          y: iy,
          button: "left",
          buttons: type === "mousePressed" ? 1 : 0,
          clickCount: 1,
          pointerType: "mouse",
        });
      }
    }
  } catch (_) {
    /* ignore */
  }

  // 4399 游戏在跨域 iframe：必须 chrome.debugger.attach(targetId)，否则键鼠只打在壳页。
  // 关键：父页仍 attach 时，Edge 常拒绝再挂 iframe → 必须先 detach 壳页再挂 targetId。
  try {
    const { list, notes } = await collectGameTargets(pageDebuggee, page.tabId, meta.url || "");
    attachNote = notes.join(";");
    const topUrls = list.slice(0, 5).map((t) => `${t.type}:${t.score}:${(t.url || "").slice(0, 80)}`);
    if (topUrls.length) attachNote += "|top=" + topUrls.join(" || ");

    let attached = false;
    if (list.length > 0) {
      try {
        await chrome.debugger.detach(pageDebuggee);
      } catch (_) {
        /* ignore */
      }
      for (const cand of list.slice(0, 8)) {
        const r = await tryAttachTarget(cand.id);
        if (!r.ok) {
          attachNote += `|fail:${String(cand.id).slice(0, 8)}:${r.err}`;
          continue;
        }
        debuggee = r.debuggee;
        attachedVia = "iframe";
        meta.url = cand.url || meta.url;
        meta.focus = "iframe-target";
        // iframe 视口即游戏坐标系，投递时不要再加壳页 iframe 偏移
        meta.offsetX = 0;
        meta.offsetY = 0;
        try {
          await chrome.debugger.sendCommand(debuggee, "Emulation.setFocusEmulationEnabled", {
            enabled: true,
          });
        } catch (_) {
          /* optional */
        }
        try {
          await chrome.debugger.sendCommand(debuggee, "Runtime.evaluate", {
            expression:
              "(() => { try { window.focus(); const c=document.querySelector('canvas'); if(c){c.tabIndex=0;c.focus();} return location.href; } catch(e) { return String(e); } })()",
            returnByValue: true,
          });
        } catch (_) {
          /* optional */
        }
        attached = true;
        attachNote += `|ok:${cand.type}:${(cand.url || "").slice(0, 60)}`;
        break;
      }
      if (!attached) {
        // 挂 iframe 全失败：重新挂回壳页，至少还能调试
        try {
          await chrome.debugger.attach(pageDebuggee, "1.3");
          debuggee = pageDebuggee;
          attachNote += "|reattach=tab";
        } catch (e2) {
          attachNote += "|reattachFail:" + (e2 && e2.message ? e2.message : e2);
        }
      }
    }
    if (!attached) {
      attachNote += "|fallback=tab";
      meta.offsetX = 0;
      meta.offsetY = 0;
    }
  } catch (e) {
    attachNote = "collect:" + (e && e.message ? e.message : e);
  }

  attachedDebuggee = debuggee;
  attachMeta = meta;
  cdpLogLeft = 8;

  const detail = `${page.title || ""} | via=${attachedVia} dpr=${meta.dpr} focus=${meta.focus}`;
  setStatus("attached", `v${BRIDGE_VERSION} ${detail}`);
  return {
    ok: true,
    tabId: page.tabId,
    title: page.title || "",
    version: BRIDGE_VERSION,
    via: attachedVia,
    dpr: meta.dpr,
    focus: meta.focus,
    url: meta.url || "",
    note: attachNote.slice(0, 400),
  };
}

function adjustMouseParams(params) {
  const p = Object.assign({}, params || {});
  const dpr = attachMeta.dpr > 0.1 ? attachMeta.dpr : 1;
  if (typeof p.x === "number") p.x = p.x / dpr - (attachMeta.offsetX || 0);
  if (typeof p.y === "number") p.y = p.y / dpr - (attachMeta.offsetY || 0);
  if (p.type === "mousePressed") {
    if (p.button === "left") p.buttons = 1;
    else if (p.button === "right") p.buttons = 2;
    else if (p.button === "middle") p.buttons = 4;
  } else if (p.type === "mouseReleased" || p.type === "mouseMoved") {
    if (p.type === "mouseReleased") p.buttons = 0;
  }
  if (!p.pointerType) p.pointerType = "mouse";
  return p;
}

async function sendCdp(method, params) {
  if (!attachedDebuggee) {
    return { ok: false, error: "NO_TAB", message: "尚未 attach", version: BRIDGE_VERSION };
  }
  let useParams = params || {};
  if (method === "Input.dispatchMouseEvent") {
    useParams = adjustMouseParams(useParams);
  }
  try {
    const result = await chrome.debugger.sendCommand(attachedDebuggee, method, useParams);
    if (cdpLogLeft > 0 && String(method).startsWith("Input.")) {
      cdpLogLeft -= 1;
      setStatus(
        "attached",
        `cdp ok ${method} ${useParams.type || ""} (${cdpLogLeft} logs left)`
      );
    }
    return { ok: true, result: result || {}, version: BRIDGE_VERSION };
  } catch (e) {
    return {
      ok: false,
      error: "CDP_ERROR",
      message: String(e && e.message ? e.message : e),
      version: BRIDGE_VERSION,
    };
  }
}

function reply(msg, body) {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  ws.send(JSON.stringify(Object.assign({ id: msg.id, type: "result" }, body)));
}

async function onMessage(raw) {
  let msg;
  try {
    msg = JSON.parse(raw);
  } catch (_) {
    return;
  }
  const type = msg.type || "";
  if (type === "ping") {
    reply(msg, { ok: true, pong: true, version: BRIDGE_VERSION });
    return;
  }
  if (type === "hello") {
    reply(msg, { ok: true, version: BRIDGE_VERSION, role: "extension" });
    setStatus("ready", `已握手 v${BRIDGE_VERSION}`);
    return;
  }
  if (type === "attach") {
    reply(msg, await attachTab(msg.titleHint || ""));
    return;
  }
  if (type === "detach") {
    await detachDebugger();
    setStatus("ready", "已 detach");
    reply(msg, { ok: true, version: BRIDGE_VERSION });
    return;
  }
  if (type === "cdp") {
    reply(msg, await sendCdp(msg.method || "", msg.params || {}));
    return;
  }
  reply(msg, { ok: false, error: "UNKNOWN", message: type });
}

function closeWs() {
  if (ws) {
    try {
      ws.close();
    } catch (_) {
      /* ignore */
    }
  }
  ws = null;
}

async function tryDiscoverAndConnect() {
  if (discoverBusy) return;
  if (ws && (ws.readyState === WebSocket.OPEN || ws.readyState === WebSocket.CONNECTING)) {
    return;
  }
  discoverBusy = true;
  try {
    for (let port = PORT_LO; port <= PORT_HI; ++port) {
      try {
        const ctrl = new AbortController();
        const timer = setTimeout(() => ctrl.abort(), 350);
        const res = await fetch(`http://127.0.0.1:${port}/qst/status`, {
          signal: ctrl.signal,
          cache: "no-store",
        });
        clearTimeout(timer);
        if (!res.ok) continue;
        const info = await res.json();
        if (!info || !info.ok || !info.token || !info.ws) continue;

        setStatus("connecting", `port=${port} v${BRIDGE_VERSION}`);
        // token 放在 URL hash 易被丢掉；query + hello 双校验。显式 ws:// 已在 manifest 授权。
        const wsUrl = `${info.ws}?token=${encodeURIComponent(info.token)}`;
        const ok = await new Promise((resolve) => {
          let settled = false;
          const done = (v) => {
            if (!settled) {
              settled = true;
              resolve(v);
            }
          };
          let socket;
          try {
            socket = new WebSocket(wsUrl);
          } catch (e) {
            setStatus("error", `WebSocket 创建失败: ${e && e.message ? e.message : e}`);
            done(false);
            return;
          }
          socket.onopen = () => {
            ws = socket;
            setStatus("connected", `ws port=${port} v${BRIDGE_VERSION}`);
            socket.send(JSON.stringify({ id: 0, type: "hello", token: info.token }));
            done(true);
          };
          socket.onmessage = (ev) => {
            onMessage(ev.data);
          };
          socket.onclose = (ev) => {
            if (ws === socket) ws = null;
            const why = `WS关闭 code=${ev.code} reason=${ev.reason || ""} wasClean=${ev.wasClean}`;
            setStatus("disconnected", why);
            done(false);
          };
          socket.onerror = () => {
            setStatus("error", `WS错误 port=${port}（若反复出现请确认 manifest 含 ws://127.0.0.1/*）`);
            try {
              socket.close();
            } catch (_) {
              /* ignore */
            }
            done(false);
          };
          setTimeout(() => done(!!(ws && ws.readyState === WebSocket.OPEN)), 2000);
        });
        if (ok && ws && ws.readyState === WebSocket.OPEN) return;
      } catch (_) {
        /* next */
      }
    }
    setStatus("waiting", "未发现鼠大侠桥（请先运行鼠大侠并启动窗口模式）");
  } finally {
    discoverBusy = false;
  }
}

chrome.runtime.onInstalled.addListener(() => {
  setStatus("installed", `v${BRIDGE_VERSION} 已安装`);
  tryDiscoverAndConnect();
});

chrome.runtime.onStartup.addListener(() => {
  tryDiscoverAndConnect();
});

chrome.alarms.create("qstBridgePoll", { periodInMinutes: 0.5 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "qstBridgePoll") tryDiscoverAndConnect();
});

chrome.debugger.onDetach.addListener((source) => {
  if (!attachedDebuggee) return;
  const sameTab =
    attachedDebuggee.tabId != null && source.tabId === attachedDebuggee.tabId;
  const sameTarget =
    attachedDebuggee.targetId && source.targetId === attachedDebuggee.targetId;
  if (sameTab || sameTarget) {
    attachedDebuggee = null;
    setStatus("connected", "debugger 已分离");
  }
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg && msg.type === "getStatus") {
    sendResponse(lastStatus);
    return false;
  }
  if (msg && msg.type === "reconnect") {
    closeWs();
    tryDiscoverAndConnect().then(() => sendResponse(lastStatus));
    return true;
  }
  return false;
});

// 保活：避免长时间无事件后 SW 彻底睡死（仍可能短睡，靠轮询恢复）
setInterval(() => {
  tryDiscoverAndConnect();
}, RECONNECT_MS);

tryDiscoverAndConnect();
